import React, { useState } from 'react';
import "./formstyle.css";

import { connect } from "react-redux";
import { store } from "./../redux/store/store";
import { addTrans } from "./../redux/action/index"; 


const AddUserForm = props => {
	const initialFormState = { id: '', amount: '', username: '', card: '' }
	const [ user, setUser ] = useState(initialFormState)

	const [amountclass, setAmountClass] = useState("noerror");
	const [cardclass, setCardClass] = useState("noerror");

	const handleInputChange = event => {
		const { name, value } = event.target

		setUser({ ...user, [name]: value })
		
	}

	return (
		<form
			onSubmit={event => {
				event.preventDefault()
				
				if (!user.amount || !user.card) {
					setAmountClass("errorclass")
					setCardClass("errorclass")
					
					return
				}
				if(!user.amout){
					setAmountClass("errorclass")
				}
				if(!user.card){
					setCardClass("errorclass")
				}
				alert("Transaction Adding..")
				//alert(Object.keys(store.getState().detailedPageApiData).length )
				
				//props.addUser(user)
				//setUser(initialFormState)
				
				user.id = Object.keys(store.getState().detailedPageApiData).length + 1;
				alert(JSON.stringify(user, null, 4))
				setAmountClass("noerror")
				setCardClass("noerror")
				store.dispatch(addTrans(user))
			}}
		>
			<div className="formsec">
				<div className="usersdiv">

					<label className="labl">
					<input type="radio" name="username" value="USER - A" onChange={handleInputChange} />
					<div>USER - A </div>
					
					</label>
					<label className="labl">
					<input type="radio" name="username" value="USER - B" onChange={handleInputChange} />
					<div>USER - B</div>
					</label>

					
					<label className="labl">
					<input type="radio" name="username" value="USER - C" onChange={handleInputChange} />
					<div>USER - C</div>
					</label>

				</div>
				<div className="cardsdiv">
					<input type="radio" name="card" className={cardclass} value="American Express" onChange={handleInputChange}/><label>American Express</label><br/>
					<input type="radio" name="card" className={cardclass} value="VISA" onChange={handleInputChange}/><label>VISA</label><br/>
					<input type="radio" name="card" className={cardclass} value="DBS PayLa" onChange={handleInputChange}/><label>DBS PayLa</label><br/>
				</div>
				<div className="amountdiv">
					{/* <input type="text" name="name" value={user.name} onChange={handleInputChange} /> */}
					<input type="number" className={amountclass} name="amount" value={user.amount} onChange={handleInputChange} max="5000" /> 
				</div>
				<div className="actiondiv">
					<button className="btnPrimary">Transfer</button>
				</div>
			</div>
			<div className="clear"></div>
			
			
			
			
		</form>
	)
}

export default AddUserForm
