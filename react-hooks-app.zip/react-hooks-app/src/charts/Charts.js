import React, {useState, useEffect} from 'react'
import Highcharts from 'highcharts';
import { connect } from "react-redux";
import { store } from "./../redux/store/store";


import {
    HighchartsChart, Chart, withHighcharts, XAxis, YAxis, Title, Subtitle, Legend, LineSeries
  } from 'react-jsx-highcharts';
  
  const plotOptions = {
    series: {
      pointStart: 1
    }
  };
  
  var Visaobj='', visaresult='', Amexobj='', amexresult='', Dbsobj='', dbsresult='';
  var objetocheck='';
  const Charts = (props) => {
      
          console.log(props);
            Visaobj = props.users.filter(o => o.card === 'VISA');
            visaresult = Visaobj.map(a => a.amount);
           //console.log(visaresult);
         
            Amexobj = props.users.filter(o => o.card === 'American Express');
            amexresult = Amexobj.map(a => a.amount);
           //console.log(amexresult);
         
         
            Dbsobj = props.users.filter(o => o.card === 'DBS PayLa');
            dbsresult = Dbsobj.map(a => a.amount);
           //console.log(dbsresult);
    
    

    return(
    <div className="app">
      <HighchartsChart plotOptions={plotOptions}>
        <Chart />
        <XAxis>
          <XAxis.Title>No of Transactions</XAxis.Title>
        </XAxis>
  
        <YAxis>
          <YAxis.Title>Amount</YAxis.Title>
          <LineSeries name="Visa" data={visaresult} />
          <LineSeries name="Amex" data={amexresult} />
          <LineSeries name="DBS PayLa" data={dbsresult} />
          
        </YAxis>
      </HighchartsChart>
    </div>
    )
  };
  
  export default withHighcharts(Charts, Highcharts);

  