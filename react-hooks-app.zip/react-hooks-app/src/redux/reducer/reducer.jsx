import {
  FETCH_PRODUCTS_BEGIN,
  FETCH_PRODUCTS_SUCCESS,
  FETCH_PRODUCTS_FAILURE,
  DETAILED_PAGE_SUCCESS_DATA
} from "../action/index";

export default (state, action) => {
  switch (action.type) {
    case "SET_HEADER_VALUE":
      return {
        ...state,
        header: action.headerData
      };
    case "FETCH_PRODUCTS_BEGIN":
      return {
        ...state,
        isFetching: true,
        displayingContent: action.payload.contentInfo
      };
    case "FETCH_PRODUCTS_SUCCESS":
      return {
        ...state,
        apiData: action.payload.products,
        displayingContent: action.payload.contentInfo,
        isFetching: false
      };
    case "DETAILED_PAGE_SUCCESS_DATA":
      return {
        ...state,
        detailedPageApiData: action.payload.detailedData,
        displayingContent: action.payload.contentInfo
      };
    default:
      return state;
  }
};
