import React, { useState, useEffect, Fragment } from 'react'
import AddUserForm from './forms/AddUserForm'
import UserTable from './tables/UserTable'
import Charts from './charts/Charts'
import "./index.css";
import ReactDOM from 'react-dom';
import Pagination from "./pagination//Pagination";
import { connect } from "react-redux";
import { store } from "./redux/store/store";
import { checkTrans } from "./redux/action/index"; 
import { setTimeout } from 'timers';

var props='';



const App = () => {

	// Data
	const usersData = [
		{ id: 1, username: 'USER - A', amount: 100, card : 'DBS PayLa'},
		{ id: 2, username: 'USER - C', amount: 289, card : 'American Express'},
		{ id: 3, username: 'USER - B', amount:897, card: 'DBS PayLa'},
		{ id: 4, username: 'USER - A', amount:200, card: 'VISA'},
		{ id: 5, username: 'USER - A', amount:1000, card: 'American Express'},
		{ id: 6, username: 'USER - C', amount:2000, card: 'American Express'},
		{ id: 7, username: 'USER - A', amount:1000, card: 'VISA'},
	]
	const [ users, setUsers ] = useState(usersData)

	useEffect(()=>{

		setTimeout(() => {
		console.log("dispatching all trans")
		store.dispatch(checkTrans());
		store.getState();
		setUsers(store.getState().detailedPageApiData);
	}, 1000);

		
	})

	
		
	const initialFormState = { id: null, username: '', amount: '' }

	
	
	const [ currentUser, setCurrentUser ] = useState(initialFormState)
	

	
	const addUser = user => {
		user.id = users.length + 1
		setUsers([ ...users, user ])
		//getChartDetails(users);
		
	}


	

	return (
		<div>
			<div className="wrapper">
			<h1 className="aligncenter">React JS - Redux Assignment</h1>
			<div>
				<div>
					<Fragment>
							<AddUserForm addUser={addUser} />
						</Fragment>
				</div>
				<div>
					{/* <UserTable users={users} /> */}
					<Pagination users={users}/>
				</div>
				<div>
					<br/>
					{ <Charts users={users}/> }
				</div>
			</div>
			</div>
		</div>
	)
}

export default App
