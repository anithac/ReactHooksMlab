Transaction App

Please follow below steps to run the application,

1. Install Node js if not presetnt
2. Then install all the dependecies of the project using => npm install
3. Start the application using => npm start
4. open mLab website and login with below credentials,
    https://mlab.com/databases/transactiondb/collections/datas
    logins,
    username: anitha
    pwd: diamonds1212
5. After adding a transaction, need to reload this mLab as othrewise it is not adding the record.