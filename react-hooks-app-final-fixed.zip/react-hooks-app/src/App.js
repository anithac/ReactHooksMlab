import React, { useState, useEffect, Fragment, useReducer } from 'react'
import AddUserForm from './forms/AddUserForm'
import UserTable from './tables/UserTable'
import Charts from './charts/Charts'
import "./index.css";
import ReactDOM from 'react-dom';
import Pagination from "./pagination//Pagination";
import reducer  from "./reducer"; 
import { setTimeout } from 'timers';


var props='', Visaobj='', visaresult='', Amexobj='', amexresult='', Dbsobj='', dbsresult='';;



const App = () => {
	
	// Data
	const usersData = [
		{ id: 1, username: 'USER - A', amount: 100, card : 'DBS PayLa'},
		{ id: 2, username: 'USER - C', amount: 289, card : 'American Express'}
	]
	const [ users, setUsers ] = useState(usersData)

	const [ backendlistusers, setUsersbackend ] = useState([]);

	async function fetchTrans(){
		//console.log("in fetchtrans")
		const response=await fetch("https://api.mlab.com/api/1/databases/transactiondb/collections/datas?apiKey=HPT7FpttU-r3Lfxj1F7uY50h-EqZibp0")
		const json = await response.json();
		setUsersbackend(json);
	}
	useEffect( ()=>{

		//console.log("in use effect")
		fetchTrans();
		
		
		
	},[])

	let [items, dispatch] = useReducer(reducer, []);
	
	const addUser = user => {

		user.id=backendlistusers.length+1;
		user.id="transId0"+user.id
		//setUsers([ ...users, user ])
		//getChartDetails(users);
		backendlistusers.push(user);
		dispatch({
            type: 'ADD_TRANS',
            backendlistusers
		})
		
		fetch("https://api.mlab.com/api/1/databases/transactiondb/collections/datas?apiKey=HPT7FpttU-r3Lfxj1F7uY50h-EqZibp0",
		{
		  method: 'post',
		  headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		  },
		  body: JSON.stringify(user)
		})
		.then(result => result.json())
		.then(json => {
		  
		  //console.log(json);
		  alert("Transaction Added")
		  //dispatch(checkTrans(json));
		  //return json;
		  //setUser(json)
		});

	}

	Visaobj = backendlistusers.filter(o => o.card === 'VISA');
	visaresult = Visaobj.map(a => a.amount);
   //console.log(visaresult);
 
	Amexobj = backendlistusers.filter(o => o.card === 'American Express');
	amexresult = Amexobj.map(a => a.amount);
   //console.log(amexresult);
 
 
	Dbsobj = backendlistusers.filter(o => o.card === 'DBS PayLa');
	dbsresult = Dbsobj.map(a => a.amount);
   //console.log(dbsresult);

	props={
		visaresult:visaresult,
		amexresult:amexresult,
		dbsresult:dbsresult
	}	

	return (
		<div>
			
		
			<div className="wrapper">
			<h1 className="aligncenter">React</h1>
			<div>
				<div>
					<Fragment>
							<AddUserForm addUser={addUser} />
						</Fragment>
				</div>
				<div>
					{/* <UserTable users={users} /> */}
					<Pagination users={backendlistusers}/>
				</div>
				<div>
					<br/>
					{ <Charts {...props}/> }
					<div style={{marginLeft:"90px"}}>
					<div style={{color:"green"}}>DBS PayLa</div>
					<div>American Express</div>
					<div style={{color:"blue"}}>VISA</div>
					</div>
				</div>
			</div>
			</div>
		</div>
	)
}

export default App
