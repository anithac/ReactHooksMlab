
export default function(state, action) {
  switch(action.type) {
      case 'ADD_TRANS': {
          
              state=action.backendlistusers
          
          return state;
      }
      default:
          return state;
  }
}


