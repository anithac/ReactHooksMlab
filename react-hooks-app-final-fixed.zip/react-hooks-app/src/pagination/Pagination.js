import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import usePagination from "use-pagination";
import TableComponent from "react-data-table-component";
import axios from "axios"
import "./pagination.css"
const Pagination = (props) => {
   // const [dataItem, setData] = useState([]);
//console.log(Object.keys(JSON.stringify(props, null, 4)))
    const darkTheme = {
        pagination: {
            fontSize: "15px",
            fontColor: "#000",
            fontWeight: "bold",
            backgroundColor: "#fff",
            buttonFontColor: "#000",
            buttonHoverBackground: "gray"
            
        }
    };

    const columns = [
        {
            name: "Transaction ID",
            sortable: false,
            selector: "id"
        },
        {
            name: "User Name",
            selector: "username",
            sortable: false
        },
        {
            name: "Payment Mode",
            selector: "card",
            sortable: false
        },
        {
            name: "Amount",
            selector: "amount",
            sortable: false
        }
       
    ];

    const Pagination = usePagination({
        items: [1, 2, 3, 4, 5],
        itemsPerPage: 3
    });
    // document.getElementById("pagination-first-page").innerHTML="First"
    // document.getElementById("pagination-last-page").innerHTML="Last"
    // document.getElementById("pagination-next-page").innerHTML=">"
    // document.getElementById("pagination-previous-page").innerHTML="<"

    return (
        <div>
            <div className="displayTbl" />
            <TableComponent
                columns={columns}
                data={props.users}
                customTheme={darkTheme}
                pagination
                paginationPerPage={4}
                paginationRowsPerPageOptions={[0]}
                paginationIconFirstPage
                paginationIconLastPage
                
                paginationTotalRows={0}
                className="displayTbl"
            />
            
        </div>
    );
};

export default Pagination;
