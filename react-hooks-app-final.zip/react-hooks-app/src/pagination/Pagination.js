import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";
import usePagination from "use-pagination";
import TableComponent from "react-data-table-component";
import axios from "axios"
import "./pagination.css"
const Pagination = (props) => {
   // const [dataItem, setData] = useState([]);
//console.log(Object.keys(JSON.stringify(props, null, 4)))
    const darkTheme = {
        pagination: {
            fontSize: "15px",
            fontColor: "#FFFFFF",
            fontWeight: "bold",
            backgroundColor: "#ccc",
            buttonFontColor: "#061c58",
            buttonHoverBackground: "rgba(230, 75, 255, .12)"
        }
    };

    const columns = [
        {
            name: "Transaction ID",
            sortable: false,
            selector: "id"
        },
        {
            name: "User Name",
            selector: "username",
            sortable: false
        },
        {
            name: "Payment Mode",
            selector: "card",
            sortable: false
        },
        {
            name: "Amount",
            selector: "amount",
            sortable: false
        }
       
    ];

    const Pagination = usePagination({
        items: [1, 2, 3, 4, 5],
        itemsPerPage: 3
    });
    

    return (
        <div>
            <div className="displayTbl" />
            <TableComponent
                columns={columns}
                data={props.users}
                customTheme={darkTheme}
                pagination
                paginationPerPage={6}
                paginationRowsPerPageOptions={[0]}
                paginationIconNext
                paginationIconPrevious
                paginationTotalRows={0}
                className="displayTbl"
            />
            
        </div>
    );
};

export default Pagination;
