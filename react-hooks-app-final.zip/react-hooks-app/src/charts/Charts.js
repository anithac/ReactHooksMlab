import React, {useState, useEffect} from 'react'
import Highcharts from 'highcharts';

import {
    HighchartsChart, Chart, withHighcharts, XAxis, YAxis, Title, Subtitle, Legend, LineSeries
  } from 'react-jsx-highcharts';
  
  const plotOptions = {
    series: {
      pointStart: 1
    }
  };
  
  
  var objetocheck='';
  const Charts = (props) => {
      
          props.visaresult.splice(0,0,0);
          props.amexresult.splice(0,0,0);
          props.dbsresult.splice(0,0,0);
          
//console.log(JSON.stringify(props,null,4)))
    return(
    <div className="app">
      <HighchartsChart plotOptions={plotOptions}>
        <Chart />
        <XAxis>
          <XAxis.Title>No of Transactions</XAxis.Title>
        </XAxis>
  
        <YAxis>
          <YAxis.Title>Amount</YAxis.Title>
          <LineSeries name="Visa" data={props.visaresult} />
          <LineSeries name="Amex" data={props.amexresult} />
          <LineSeries name="DBS PayLa" data={props.dbsresult} />
          
        </YAxis>
      </HighchartsChart>
    </div>
    )
  };
  
  export default withHighcharts(Charts, Highcharts);

  