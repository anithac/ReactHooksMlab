# ReactReduxTrial
Download as ZIP,
Extract it, this is the application folder, and from here only need to run the application.
open cmd prmopt and type cmd, 
=> npm install.
after all the dependencies added, type below cmd to run the application,
=> npm start


it should start server and application on http://localhost:3000/