import React from 'react'
import "./tablestyle.css";

const UserTable = props => (
  <table className="transactiontbl" cellPadding="10" cellSpacing="10">
    <thead>
      <tr>
        <th>Transaction ID</th>
        <th>User Name</th>
        <th>Payment Mode</th>
        <th>Amount</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (
        props.users.map(user => (
          <tr key={user.id}>
            <td>{user.id}</td>
            <td>{user.username}</td>
            <td>{user.card}</td>
            <td>{user.amount}</td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={3}>No users</td>
        </tr>
      )}
    </tbody>
  </table>
)

export default UserTable
