import { createStore, applyMiddleware, compose } from "redux";
import reducer from "../reducer/reducer";
import thunk from "redux-thunk";

const initialState = {
  isFetching: false,
  detailedPageApiData: [],
  displayingContent: "",
  apiSuccessData: [],
};

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const middleWare = composeEnhancers(applyMiddleware(thunk));
export const store = createStore(reducer, initialState, middleWare);
