import {
  DETAILED_PAGE_SUCCESS_DATA
} from "../action/index";

export default (state, action) => {
  switch (action.type) {
    case "DETAILED_PAGE_SUCCESS_DATA":
      return {
        ...state,
        detailedPageApiData: action.payload.detailedData,
        displayingContent: action.payload.contentInfo
      }
    default:
      return state;
  }
};
