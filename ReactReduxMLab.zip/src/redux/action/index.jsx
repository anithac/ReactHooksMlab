export const API_BEGIN = "API_BEGIN";
export const API_SUCCESS = "API_SUCCESS";
export const DETAILED_PAGE_SUCCESS_DATA = "DETAILED_PAGE_SUCCESS_DATA";



export const apiCallBegin = () => ({
  type: API_BEGIN,
  payload: { contentInfo: "" }
});


export const detailedPageSuccess = detailedData => ({
  type: DETAILED_PAGE_SUCCESS_DATA,
  payload: { detailedData, contentInfo: "done" }
});

export function checkTrans(){
  console.log("getting all trans action")
  return dispatch => {
    dispatch(apiCallBegin());
    return fetch("https://api.mlab.com/api/1/databases/transactiondb/collections/datas?apiKey=HPT7FpttU-r3Lfxj1F7uY50h-EqZibp0")
    .then(result => result.json())
    .then(json => {
      dispatch(detailedPageSuccess(json));
      //console.log(json);
      return json;
    });
  };
}

export function addTrans(objecttoadd){
  return dispatch => {
    dispatch(apiCallBegin());
    return fetch("https://api.mlab.com/api/1/databases/transactiondb/collections/datas?apiKey=HPT7FpttU-r3Lfxj1F7uY50h-EqZibp0",
    {
      method: 'post',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(objecttoadd)
    })
    .then(result => result.json())
    .then(json => {
      dispatch(detailedPageSuccess(json));
      //console.log(json);
      alert("Transaction Added")
      return json;
    });
  };
}



